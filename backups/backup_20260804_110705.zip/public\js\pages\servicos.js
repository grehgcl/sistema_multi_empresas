// pages/servicos.js - Versão Mobile Friendly com Cards e Duração
let listaServicosGlobal = [];

async function carregarServicos() {
    if (typeof window.carregarCSS === 'function') {
        window.carregarCSS('servicos');
        console.log('🎨 CSS carregado: servicos.css');
    }
    ativarBotao('servicos');

    const usuario = JSON.parse(localStorage.getItem('usuario'));
    if (usuario.role !== 'dono') {
        document.getElementById('content').innerHTML = `
            <div class="card">
                <div class="empty-state">
                    <i class="fas fa-lock"></i>
                    <h4>Acesso negado</h4>
                    <p>Apenas donos podem acessar serviços.</p>
                </div>
            </div>
        `;
        return;
    }

    let html = `
        <div class="fade-in">
            <!-- Header -->
            <div class="dashboard-header">
                <div>
                    <h2 class="page-title">💇 Serviços</h2>
                    <p class="page-subtitle">
                        <i class="fas fa-cut"></i> 
                        Gerencie os serviços da sua barbearia
                    </p>
                </div>
                <div class="dashboard-actions">
                    <button class="btn btn-primary" onclick="abrirModalServico()">
                        <i class="fas fa-plus"></i> Novo Serviço
                    </button>
                </div>
            </div>

            <!-- Estatísticas Rápidas -->
            <div class="servico-stats" id="servicoStats">
                <div class="stat-mini">
                    <span class="stat-mini-value" id="totalServicos">0</span>
                    <span class="stat-mini-label">Total</span>
                </div>
                <div class="stat-mini">
                    <span class="stat-mini-value" id="ativosCount">0</span>
                    <span class="stat-mini-label">✅ Ativos</span>
                </div>
                <div class="stat-mini">
                    <span class="stat-mini-value" id="inativosCount">0</span>
                    <span class="stat-mini-label">⛔ Inativos</span>
                </div>
            </div>

            <!-- Lista de Serviços -->
            <div class="card">
                <div id="listaServicosContainer">
                    <div style="text-align: center; padding: 40px;">
                        <div class="loading-spinner" style="display: inline-block;"></div>
                        <p>Carregando serviços...</p>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById('content').innerHTML = html;

    // 🔥 ESPERA O DOM CARREGAR E DEPOIS CARREGA OS SERVIÇOS
    setTimeout(() => {
        carregarListaServicos();
    }, 100);
}

// ============================================
// CARREGAR LISTA DE SERVIÇOS - VERSÃO CORRIGIDA
// ============================================

async function carregarListaServicos() {
    const token = localStorage.getItem('token');
    const container = document.getElementById('listaServicosContainer');

    if (!container) {
        console.error('❌ Container não encontrado!');
        return;
    }

    try {
        console.log('🔄 Carregando serviços...');

        const res = await fetch('/api/servicos/todos', {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const result = await res.json();

        if (result.success) {
            listaServicosGlobal = result.data;

            // 🔥 FORÇA A DETECÇÃO DE MOBILE
            const isMobile = window.innerWidth < 768 || window.screen.width < 768;

            console.log('📱 Modo mobile:', isMobile);
            console.log('📊 Total de serviços:', listaServicosGlobal.length);
            console.log('📋 Serviços:', listaServicosGlobal);

            // Atualizar estatísticas
            const total = listaServicosGlobal.length;
            const ativos = listaServicosGlobal.filter(s => (s.ativo == 1 || s.ativo == true)).length;
            const inativos = listaServicosGlobal.filter(s => s.ativo === 0);

            document.getElementById('totalServicos').textContent = total;
            document.getElementById('ativosCount').textContent = ativos;
            document.getElementById('inativosCount').textContent = inativos;

            if (listaServicosGlobal.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-cut"></i>
                        <h4>Nenhum serviço cadastrado</h4>
                        <p>Comece criando seu primeiro serviço!</p>
                        <button class="btn btn-primary btn-sm" onclick="abrirModalServico()">
                            <i class="fas fa-plus"></i> Novo Serviço
                        </button>
                    </div>
                `;
                return;
            }

            let html = '';

            if (isMobile) {
                // ============================================
                // VERSÃO MOBILE - CARDS
                // ============================================
                console.log('📱 Renderizando MOBILE - Cards');

                html = `<div style="display:flex;flex-direction:column;gap:10px;">`;

                for (let s of listaServicosGlobal) {
                    const isAtivo = (s.ativo == 1 || s.ativo == true);
                    const statusClass = isAtivo ? 'ativo' : 'inativo';
                    const statusLabel = isAtivo ? '✅ Ativo' : '⛔ Inativo';
                    const valorFormatado = (parseFloat(s.valor) || 0).toFixed(2);

                    html += `
                        <div style="
                            background: var(--bg-card);
                            border-radius: 16px;
                            padding: 16px;
                            border: 1px solid var(--border-color);
                            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
                            transition: all 0.3s ease;
                        ">
                            <!-- Header -->
                            <div style="
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                margin-bottom: 10px;
                                padding-bottom: 10px;
                                border-bottom: 1px solid var(--border-color);
                            ">
                                <div style="
                                    display: flex;
                                    align-items: center;
                                    gap: 8px;
                                    font-size: 16px;
                                    font-weight: 600;
                                    color: var(--text-primary);
                                ">
                                    <span style="font-size: 20px;">✂️</span>
                                    <span>${escapeHtml(s.nome)}</span>
                                </div>
                                <span style="
                                    display: inline-flex;
                                    align-items: center;
                                    gap: 4px;
                                    padding: 4px 12px;
                                    border-radius: 9999px;
                                    font-size: 11px;
                                    font-weight: 600;
                                    background: ${isAtivo ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)'};
                                    color: ${isAtivo ? '#22c55e' : '#ef4444'};
                                ">
                                    <span style="
                                        width: 6px;
                                        height: 6px;
                                        border-radius: 50%;
                                        display: inline-block;
                                        background: ${isAtivo ? '#22c55e' : '#ef4444'};
                                    "></span>
                                    ${statusLabel}
                                </span>
                            </div>

                            <!-- Body -->
                            <div style="
                                display: grid;
                                grid-template-columns: 1fr 1fr;
                                gap: 4px 12px;
                                margin: 8px 0 12px 0;
                            ">
                                <div style="display:flex;flex-direction:column;gap:2px;padding:4px 0;">
                                    <span style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;font-weight:600;">📝 Descrição</span>
                                    <span style="font-size:13px;font-weight:500;color:var(--text-primary);">${escapeHtml(s.descricao || '-')}</span>
                                </div>
                                <div style="display:flex;flex-direction:column;gap:2px;padding:4px 0;">
                                    <span style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;font-weight:600;">💰 Valor</span>
                                    <span style="font-size:13px;font-weight:700;color:var(--primary);">R$ ${valorFormatado}</span>
                                </div>
                                <div style="display:flex;flex-direction:column;gap:2px;padding:4px 0;grid-column: span 2;">
                                    <span style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;font-weight:600;">⏱️ Duração</span>
                                    <span style="font-size:13px;font-weight:500;color:var(--text-primary);">${s.duracao || 30} minutos</span>
                                </div>
                            </div>

                            <!-- Actions -->
                            <div style="
                                display: flex;
                                gap: 6px;
                                flex-wrap: wrap;
                                padding-top: 10px;
                                border-top: 1px solid var(--border-color);
                            ">
                                <button onclick="editarServico(${s.id})" style="
                                    padding: 6px 14px;
                                    border-radius: 10px;
                                    border: 1px solid rgba(102,126,234,0.3);
                                    background: var(--bg-hover);
                                    color: var(--primary);
                                    font-size: 12px;
                                    font-weight: 500;
                                    cursor: pointer;
                                    transition: all 0.3s ease;
                                    display: inline-flex;
                                    align-items: center;
                                    gap: 4px;
                                    flex: 1;
                                    justify-content: center;
                                    min-width: 60px;
                                ">
                                    <i class="fas fa-pen"></i> Editar
                                </button>
                                <button onclick="toggleServico(${s.id})" style="
                                    padding: 6px 14px;
                                    border-radius: 10px;
                                    border: 1px solid ${isAtivo ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.3)'};
                                    background: var(--bg-hover);
                                    color: ${isAtivo ? '#22c55e' : '#ef4444'};
                                    font-size: 12px;
                                    font-weight: 500;
                                    cursor: pointer;
                                    transition: all 0.3s ease;
                                    display: inline-flex;
                                    align-items: center;
                                    gap: 4px;
                                    flex: 1;
                                    justify-content: center;
                                    min-width: 60px;
                                ">
                                    <i class="fas ${isAtivo ? 'fa-toggle-on' : 'fa-toggle-off'}"></i> 
                                    ${isAtivo ? 'Desativar' : 'Ativar'}
                                </button>
                                <button onclick="excluirServico(${s.id})" style="
                                    padding: 6px 14px;
                                    border-radius: 10px;
                                    border: 1px solid rgba(239,68,68,0.3);
                                    background: var(--bg-hover);
                                    color: #ef4444;
                                    font-size: 12px;
                                    font-weight: 500;
                                    cursor: pointer;
                                    transition: all 0.3s ease;
                                    display: inline-flex;
                                    align-items: center;
                                    gap: 4px;
                                    flex: 1;
                                    justify-content: center;
                                    min-width: 60px;
                                ">
                                    <i class="fas fa-trash"></i> Excluir
                                </button>
                            </div>
                        </div>
                    `;
                }
                html += `</div>`;

            } else {
                // ============================================
                // VERSÃO DESKTOP - TABELA
                // ============================================
                console.log('💻 Renderizando DESKTOP - Tabela');

                html = `
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Descrição</th>
                                    <th>Valor</th>
                                    <th>⏱️ Duração</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${listaServicosGlobal.map(s => `
                                    <tr>
                                        <td><strong>${escapeHtml(s.nome)}</strong></td>
                                        <td>${escapeHtml(s.descricao || '-')}</td>
                                        <td><span class="valor">R$ ${(parseFloat(s.valor) || 0).toFixed(2)}</span></td>
                                        <td><span style="background:var(--bg-hover);padding:2px 12px;border-radius:12px;font-size:12px;font-weight:600;">${s.duracao || 30} min</span></td>
                                        <td>
                                            <span class="status-badge ${(s.ativo == 1 || s.ativo == true) ? 'ativo' : 'inativo'}">
                                                <span class="dot"></span>
                                                ${(s.ativo == 1 || s.ativo == true) ? '✅ Ativo' : '⛔ Inativo'}
                                            </span>
                                        </td>
                                        <td>
                                            <div class="actions-cell">
                                                <button class="btn-icon btn-edit" onclick="editarServico(${s.id})" title="Editar">
                                                    <i class="fas fa-pen"></i>
                                                </button>
                                                <button class="btn-icon ${(s.ativo == 1 || s.ativo == true) ? 'btn-toggle-on' : 'btn-toggle-off'}" onclick="toggleServico(${s.id})" title="${(s.ativo == 1 || s.ativo == true) ? 'Desativar' : 'Ativar'}">
                                                    <i class="fas ${(s.ativo == 1 || s.ativo == true) ? 'fa-toggle-on' : 'fa-toggle-off'}"></i>
                                                </button>
                                                <button class="btn-icon btn-delete" onclick="excluirServico(${s.id})" title="Excluir">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }

            container.innerHTML = html;
            console.log('✅ Serviços renderizados com sucesso!');

        } else {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h4>Erro ao carregar serviços</h4>
                    <p>${result.message || 'Tente novamente mais tarde.'}</p>
                    <button class="btn btn-primary btn-sm" onclick="carregarListaServicos()">
                        <i class="fas fa-sync"></i> Tentar Novamente
                    </button>
                </div>
            `;
        }
    } catch (error) {
        console.error('❌ Erro:', error);
        document.getElementById('listaServicosContainer').innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h4>Erro ao carregar serviços</h4>
                <p>${error.message || 'Tente novamente mais tarde.'}</p>
                <button class="btn btn-primary btn-sm" onclick="carregarListaServicos()">
                    <i class="fas fa-sync"></i> Tentar Novamente
                </button>
            </div>
        `;
    }
}

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// ABRIR MODAL SERVIÇO (COM DURAÇÃO)
// ============================================

function abrirModalServico(servico = null) {
    const isEdit = servico !== null;

    const modalDiv = document.createElement('div');
    modalDiv.id = 'modalServicoCustom';
    modalDiv.className = 'modal';
    modalDiv.style.display = 'flex';

    modalDiv.innerHTML = `
        <div class="modal-content" style="max-width: 480px; width: 90%;">
            <h3>${isEdit ? '✏️ Editar' : '➕ Novo'} Serviço</h3>
            <input type="hidden" id="servicoEditId" value="${isEdit ? servico.id : ''}">

            <div class="form-group">
                <label>Nome *</label>
                <input type="text" id="servicoNome" class="form-control" value="${isEdit ? escapeHtml(servico.nome) : ''}" placeholder="Ex: Corte de Cabelo">
            </div>

            <div class="form-group">
                <label>Descrição</label>
                <textarea id="servicoDescricao" class="form-control" rows="3" placeholder="Descrição do serviço...">${isEdit ? (servico.descricao || '') : ''}</textarea>
            </div>

            <div class="form-group">
                <label>Valor (R$) *</label>
                <input type="number" id="servicoValor" class="form-control" step="0.01" value="${isEdit ? servico.valor : ''}" placeholder="0,00">
            </div>

            <div class="form-group">
                <label>⏱️ Duração (minutos) *</label>
                <select id="servicoDuracao" class="form-control">
    <option value="15" ${isEdit && servico.duracao === 15 ? 'selected' : ''}>15 minutos</option>
    <option value="30" ${isEdit && (servico.duracao === 30 || !servico) ? 'selected' : ''}>30 minutos</option>
    <option value="45" ${isEdit && servico.duracao === 45 ? 'selected' : ''}>45 minutos</option>
    <option value="50" ${isEdit && servico.duracao === 50 ? 'selected' : ''}>50 minutos</option>
    <option value="60" ${isEdit && servico.duracao === 60 ? 'selected' : ''}>1 hora (60 min)</option>
    <option value="90" ${isEdit && servico.duracao === 90 ? 'selected' : ''}>1h30 (90 min)</option>
    <option value="120" ${isEdit && servico.duracao === 120 ? 'selected' : ''}>2 horas (120 min)</option>
    <option value="180" ${isEdit && servico.duracao === 180 ? 'selected' : ''}>3 horas (180 min)</option>
    <option value="240" ${isEdit && servico.duracao === 240 ? 'selected' : ''}>4 horas (240 min)</option>
    <option value="300" ${isEdit && servico.duracao === 300 ? 'selected' : ''}>5 horas (300 min)</option>
    <option value="360" ${isEdit && servico.duracao === 360 ? 'selected' : ''}>6 horas (360 min)</option>
    <option value="420" ${isEdit && servico.duracao === 420 ? 'selected' : ''}>7 horas (420 min)</option>
    <option value="480" ${isEdit && servico.duracao === 480 ? 'selected' : ''}>8 horas (480 min)</option>
</select>
                <small class="text-muted" style="display:block;margin-top:4px;color:var(--text-muted);">
                    <i class="fas fa-info-circle"></i> 
                    A agenda respeitará este tempo, bloqueando os horários necessários
                </small>
            </div>

            ${isEdit ? `
            <div class="form-group">
                <label>Status</label>
                <select id="servicoStatus" class="form-control">
                    <option value="1" ${(servico.ativo == 1 || servico.ativo == true) ? 'selected' : ''}>✅ Ativo</option>
                    <option value="0" ${servico.ativo === 0 ? 'selected' : ''}>⛔ Inativo</option>
                </select>
            </div>
            ` : ''}

            <div class="modal-buttons">
                <button onclick="fecharModalServico()">Cancelar</button>
                <button onclick="salvarServico()">Salvar</button>
            </div>
        </div>
    `;

    document.body.appendChild(modalDiv);
}

function fecharModalServico() {
    const modal = document.getElementById('modalServicoCustom');
    if (modal) modal.remove();
}

// ============================================
// SALVAR SERVIÇO (COM DURAÇÃO)
// ============================================

async function salvarServico() {
    const id = document.getElementById('servicoEditId').value;
    const nome = document.getElementById('servicoNome').value;
    const descricao = document.getElementById('servicoDescricao').value;
    const valor = document.getElementById('servicoValor').value;
    const duracao = document.getElementById('servicoDuracao').value;

    if (!nome || !valor) {
        showToast('Nome e valor são obrigatórios', 'warning');
        return;
    }

    if (!duracao || parseInt(duracao) < 5 || parseInt(duracao) > 480) {
        showToast('Duração deve ser pelo menos 5 minutos', 'warning');
        return;
    }

    showLoading();

    const token = localStorage.getItem('token');
    const url = id ? `/api/servicos/${id}` : '/api/servicos';
    const method = id ? 'PUT' : 'POST';

    const body = {
        nome: nome,
        descricao: descricao,
        valor: parseFloat(valor),
        duracao: parseInt(duracao)
    };

    if (id) {
        body.ativo = parseInt(document.getElementById('servicoStatus')?.value || 1);
    }

    try {
        const res = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify(body)
        });

        const result = await res.json();

        if (result.success) {
            showToast(result.message, 'success');
            fecharModalServico();
            await carregarListaServicos();
        } else {
            showToast('Erro: ' + result.message, 'error');
        }
    } catch (error) {
        console.error('Erro:', error);
        showToast('Erro ao salvar serviço', 'error');
    }

    hideLoading();
}

// ============================================
// EDITAR SERVIÇO
// ============================================

async function editarServico(id) {
    const servico = listaServicosGlobal.find(s => s.id === id);
    if (servico) {
        abrirModalServico(servico);
    }
}

// ============================================
// TOGGLE (ATIVAR/DESATIVAR) SERVIÇO
// ============================================

async function toggleServico(id) {
    const servico = listaServicosGlobal.find(s => s.id === id);
    if (!servico) return;

    const acao = (servico.ativo == 1 || servico.ativo == true) ? 'desativar' : 'ativar';
    if (!confirm(`Tem certeza que deseja ${acao} este serviço?`)) return;

    showLoading();

    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`/api/servicos/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify({
                nome: servico.nome,
                descricao: servico.descricao,
                valor: servico.valor,
                duracao: servico.duracao || 30,
                ativo: (servico.ativo == 1 || servico.ativo == true) ? 0 : 1
            })
        });

        const result = await res.json();

        if (result.success) {
            showToast(`Serviço ${acao}do com sucesso!`, 'success');
            await carregarListaServicos();
        } else {
            showToast('Erro: ' + result.message, 'error');
        }
    } catch (error) {
        console.error('Erro:', error);
        showToast('Erro ao alterar status', 'error');
    }

    hideLoading();
}

// ============================================
// EXCLUIR SERVIÇO
// ============================================

async function excluirServico(id) {
    const servico = listaServicosGlobal.find(s => s.id === id);
    if (!servico) return;

    if (!confirm(`Tem certeza que deseja excluir "${servico.nome}"?`)) return;

    showLoading();

    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`/api/servicos/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const result = await res.json();

        if (result.success) {
            showToast(result.message, 'success');
            await carregarListaServicos();
        } else {
            showToast('Erro: ' + result.message, 'error');
        }
    } catch (error) {
        console.error('Erro:', error);
        showToast('Erro ao excluir serviço', 'error');
    }

    hideLoading();
}

// ============================================
// ATUALIZAR AO REDIMENSIONAR A TELA
// ============================================

let resizeTimeoutServicos;
window.addEventListener('resize', function () {
    clearTimeout(resizeTimeoutServicos);
    resizeTimeoutServicos = setTimeout(function () {
        if (document.getElementById('listaServicosContainer')) {
            carregarListaServicos();
        }
    }, 300);
});

// ============================================
// EXPORTAR FUNÇÕES GLOBAIS
// ============================================

window.carregarServicos = carregarServicos;
window.abrirModalServico = abrirModalServico;
window.fecharModalServico = fecharModalServico;
window.salvarServico = salvarServico;
window.editarServico = editarServico;
window.toggleServico = toggleServico;
window.excluirServico = excluirServico;
window.carregarListaServicos = carregarListaServicos;

console.log('✅ servicos.js carregado com campo DURAÇÃO e MOBILE FIX!');